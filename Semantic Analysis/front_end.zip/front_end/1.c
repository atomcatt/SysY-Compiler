#include <stdio.h>

const int a = 5;
const int b = 10, c = 15;
const int d[2][2] = {1, 1, 1, 1};

int main(){
    int x = 0;
    int y = 12, cx = 11;
    int arr[2][2] = {1, 2, 3, 4};
    return 0;
}