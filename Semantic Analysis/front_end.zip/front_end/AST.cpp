#include "AST.hpp"
#include "const_eval_helper.hpp"
#include "symbol_table.hpp"
#include <variant>
#include <type_traits>
#include <numeric>

using namespace ConstEvalHelper;

static SymbolTable const_eval_symbol_table;

void CompUnitAST::const_eval(BaseAST *&root) {
    for (DeclAST* decl : decls) {
        const_eval_helper(decl);
    }
    for (FuncDefAST* func_def : func_defs) {
        const_eval_helper(func_def);
    }
}

void DeclAST::const_eval(BaseAST *&root) {
    if (std::holds_alternative<ConstDeclAST*>(decl)) {
        const_eval_helper(std::get<ConstDeclAST*>(decl));
    } else {
        const_eval_helper(std::get<VarDeclAST*>(decl));
    }
}

void ConstDeclAST::const_eval(BaseAST *&root) {
    for (ConstDefAST* const_def : const_defs) {
        for (ExpAST* exp : const_def->dim) {
            const_eval_helper(exp);
            array_dim_check(exp);
        }
        if (!const_def->const_init_val) {
            throw std::runtime_error("constant variable must be initialized");
        }
        fix_nested_array(const_def->const_init_val, const_def->dim);
        const_eval_helper(const_def->const_init_val);\
        const_initializer_assert(const_def->const_init_val);
        if (const_def->dim.empty()) {
            auto num_exp = dynamic_cast<NumExpAST*>(std::get<ExpAST*>(const_def->const_init_val->value));
            const_eval_symbol_table.insert(const_def->ident, new Symbol(SymbolType::CONST_INT, 0, num_exp->value));
        } else {
            std::vector<int> const_array_values;
            auto const_init_val_list = std::get<ConstInitValListAST*>(const_def->const_init_val->value);
            for (ConstInitValAST* const_init_val : const_init_val_list->const_init_vals) {
                if (std::holds_alternative<ExpAST*>(const_init_val->value)) {
                    auto num_exp = dynamic_cast<NumExpAST*>(std::get<ExpAST*>(const_init_val->value));
                    const_array_values.push_back(num_exp->value);
                } else {
                    auto const_init_val_list = std::get<ConstInitValListAST*>(const_init_val->value);
                    for (ConstInitValAST* const_init_val : const_init_val_list->const_init_vals) {
                        auto num_exp = dynamic_cast<NumExpAST*>(std::get<ExpAST*>(const_init_val->value));
                        const_array_values.push_back(num_exp->value);
                    }
                }
            }
            const_eval_symbol_table.insert(const_def->ident, new Symbol(SymbolType::CONST_ARRAY, 0, const_array_values));
        }
    }
}

void VarDeclAST::const_eval(BaseAST *&root) {
    for (VarDefAST* var_def : var_defs) {
        for (ExpAST* exp : var_def->dim) {
            const_eval_helper(exp);
            array_dim_check(exp);
        }
        if (!var_def->init_val) {
            continue;
        }
        fix_nested_array(var_def->init_val, var_def->dim);
        const_eval_helper(var_def->init_val);
        initializer_type_fix(var_def->init_val);
    }
}

void ConstInitValAST::const_eval(BaseAST *&root) {
    if (std::holds_alternative<ExpAST*>(value)) {
        const_eval_helper(std::get<ExpAST*>(value));
    } else {
        const_eval_helper(std::get<ConstInitValListAST*>(value));
    }
}

void ConstInitValListAST::const_eval(BaseAST *&root) {
    for (ConstInitValAST* const_init_val : const_init_vals) {
        const_eval_helper(const_init_val);
    }
}

void InitValAST::const_eval(BaseAST *&root) {
    if (std::holds_alternative<ExpAST*>(value)) {
        const_eval_helper(std::get<ExpAST*>(value));
    } else {
        const_eval_helper(std::get<InitValListAST*>(value));
    }
}

void InitValListAST::const_eval(BaseAST *&root) {
    for (InitValAST* init_val : init_vals) {
        const_eval_helper(init_val);
    }
}

void FuncFParamAST::const_eval(BaseAST *&root) {
    for (ExpAST *&exp : dim) {
        if (!exp) {
            continue;
        }
        const_eval_helper(exp);
        array_dim_check(exp);
    }
}

void BlockAST::const_eval(BaseAST *&root) {
    for (BlockItemAST *&block_item : block_items) {
        const_eval_helper(block_item);
    }
}

void BlockItemAST::const_eval(BaseAST *&root) {
    if (std::holds_alternative<DeclAST*>(block_item)) {
        const_eval_helper(std::get<DeclAST*>(block_item));
    } else {
        const_eval_helper(std::get<StmtAST*>(block_item));
    }
}

void FuncDefAST::const_eval(BaseAST *&root) {
    const_eval_symbol_table.push_scope();
    for (FuncFParamAST *&f_arg : f_args) {
        const_eval_helper(f_arg);
    }
    const_eval_helper(block);
    const_eval_symbol_table.pop_scope();
}

void NullStmtAST::const_eval(BaseAST *&root) {
    // なにも出来ません　TAT
}

void AssignStmtAST::const_eval(BaseAST *&root) {
    // なにも出来なかった　TAT
}

void ExpStmtAST::const_eval(BaseAST *&root) {
    // なにも出来ない　TAT
}

void BlockStmtAST::const_eval(BaseAST *&root) {
    const_eval_symbol_table.push_scope();
    for (BlockItemAST *&block_item : block_items) {
        const_eval_helper(block_item);
    }
    const_eval_symbol_table.pop_scope();
}

void IfStmtAST::const_eval(BaseAST *&root) {
    const_eval_helper(then_stmt);
    if(else_stmt) {
        const_eval_helper(else_stmt);
    }
}

void WhileStmtAST::const_eval(BaseAST *&root) {
    const_eval_helper(stmt);
}

void BreakStmtAST::const_eval(BaseAST *&root) {
    // なにも出来ない　TAT
}

void ContinueStmtAST::const_eval(BaseAST *&root) {
    // なにも出来ない　TAT
}

void ReturnStmtAST::const_eval(BaseAST *&root) {
    // なにも出来ない　TAT
}

void UnaryExpAST::const_eval(BaseAST *&root) {
    const_eval_helper(value);
    if(op == std::string("+")) {
        root = value;
        return ;
    }
    if(op == std::string("-")) {
        auto num_exp = dynamic_cast<NumExpAST*>(value);
        if(!num_exp) {
            return ;
        }
        root = new NumExpAST(-(num_exp->value));
    }
}

void FuncCallAST::const_eval(BaseAST *&root) {
    // なにも出来ない　TAT
}

void BinaryExpAST::const_eval(BaseAST *&root) {
    const_eval_helper(lhs);
    const_eval_helper(rhs);
    auto lhs_num_exp = dynamic_cast<NumExpAST*>(lhs);
    auto rhs_num_exp = dynamic_cast<NumExpAST*>(rhs);
    if (!lhs_num_exp || !rhs_num_exp) {
        return ;
    }
    if (op == std::string("+")) {
        root = new NumExpAST(lhs_num_exp->value + rhs_num_exp->value);
        return ;
    } else if (op == std::string("-")) {
        root = new NumExpAST(lhs_num_exp->value - rhs_num_exp->value);
        return ;
    } else if (op == std::string("*")) {
        root = new NumExpAST(lhs_num_exp->value * rhs_num_exp->value);
        return ;
    } else if (op == std::string("/")) {
        root = new NumExpAST(lhs_num_exp->value / rhs_num_exp->value);
        return ;
    } else if (op == std::string("%")) {
        root = new NumExpAST(lhs_num_exp->value % rhs_num_exp->value);
        return ;
    } else if (op == std::string("==")) {
        root = new NumExpAST(lhs_num_exp->value == rhs_num_exp->value);
        return ;
    } else if (op == std::string("!=")) {
        root = new NumExpAST(lhs_num_exp->value != rhs_num_exp->value);
        return ;
    } else if (op == std::string("<")) {
        root = new NumExpAST(lhs_num_exp->value < rhs_num_exp->value);
        return ;
    } else if (op == std::string("<=")) {
        root = new NumExpAST(lhs_num_exp->value <= rhs_num_exp->value);
        return ;
    } else if (op == std::string(">")) {
        root = new NumExpAST(lhs_num_exp->value > rhs_num_exp->value);
        return ;
    } else if (op == std::string(">=")) {
        root = new NumExpAST(lhs_num_exp->value >= rhs_num_exp->value);
        return ;
    } else if (op == std::string("&&")) {
        root = new NumExpAST(lhs_num_exp->value && rhs_num_exp->value);
        return ;
    } else if (op == std::string("||")) {
        root = new NumExpAST(lhs_num_exp->value || rhs_num_exp->value);
        return ;
    } else {
        throw std::runtime_error("Unknown binary operator");
    }
}

void NumExpAST::const_eval(BaseAST *&) {
    // なにも出来ない　TAT
}

void VarExpAST::const_eval(BaseAST *&root) {
    auto symbol = const_eval_symbol_table.try_lookup(ident);
    if (!symbol) {
        return ;
    }
    auto &value = symbol->const_value;
    root = new NumExpAST(value);
}