#pragma once
#include <stdexcept>
#include <vector>
#include <string>
#include <memory>
#include <variant>
// #include "const_eval_helper.hpp"


enum struct Type {
    COMPUNIT,
    EXTERNALDEF,
    DECL,
    CONSTDECL,
    CONSTDEFLIST,
    CONSTDEF,
    CONSTARRDEF,
    CONSTINITVAL,
    CONSTINITVALLIST,
    CONSTEXP,
    VARDECL,
    VARDEFLIST,
    VARDEF,
    ARRDEF,
    INITVAL,
    INITVALLIST,
    FUNCDEF,
    FUNCFPARAMS,
    FUNCFPARAM,
    BLOCK,
    BLOCKGROUP,
    BLOCKITEM,
    STMT,
    NULLSTMT,
    ASSIGNSTMT,
    EXPSTMT,
    BLOCKSTMT,
    IFSTMT,
    WHILESTMT,
    BREAKSTMT,
    CONTINUESTMT,
    RETURNSTMT,
    LVAL,
    COND,
    EXP,
    PRIMARYEXP,
    UNARYEXP,
    BINARYEXP,
    VAREXP,
    FUNCCALL,
    UNARYOP,
    FUNCRPARAMS,
    MULEXP,
    ADDEXP,
    RELEXP,
    EQEXP,
    LANDEXP,
    LOREXP,
};

struct BaseAST;
struct CompUnitAST;
struct ExternalDefAST;
struct DeclAST;

struct ConstExpAST;
struct ConstDeclAST;
struct ConstDefListAST;
struct ConstDefAST;
struct ConstArrDefAST;
struct ConstInitValAST;
struct ConstInitValListAST;

struct VarDeclAST;
struct VarDefListAST;
struct VarDefAST;
struct ArrDefAST;
struct InitValAST;
struct InitValListAST;

struct FuncDefAST;
struct FuncFParamsAST;
struct FuncFParamAST;

struct BlockAST;
struct BlockGroupAST;
struct BlockItemAST;

/**
 * Stmt :== ; -> NullStmtAST
 *          | Exp ; -> ExpStmtAST
 *          | LVal = Exp ;  -> AssignStmtAST
            | Block     -> BlockStmtAST
            | if ( Cond ) Stmt | if ( Cond ) Stmt else Stmt -> IfStmtAST
            | while ( Cond ) Stmt   -> WhileStmtAST
            | break ;   -> BreakStmtAST
            | continue ;    -> ContinueStmtAST
            | return ;  -> ReturnStmtAST
            | return Exp ;  -> ReturnStmtAST
*/
struct StmtAST;
struct NullStmtAST;
struct AssignStmtAST;
struct ExpStmtAST;
struct BlockStmtAST;
struct IfStmtAST;
struct WhileStmtAST;
struct BreakStmtAST;
struct ContinueStmtAST;
struct ReturnStmtAST;

struct LValAST;

struct CondAST;

struct BinaryExpAST;
struct VarExpAST;
struct NumExpAST;

struct ExpAST;
struct PrimaryExpAST;
struct UnaryExpAST;
struct FuncCallAST;
struct UnaryOpAST;
struct FuncRParamsAST;
struct MulExpAST;
struct AddExpAST;
struct RelExpAST;
struct EqExpAST;
struct LAndExpAST;
struct LOrExpAST;


// struct Node {
//     int value;
//     char *string;
//     std::vector<Node *> values;
// };

// struct ConstDef {
//     std::string name;
//     std::vector<int> values;
//     std::vector<int> size;
// };

struct BaseAST {
public:
    Type type;
    int node_index;
    //virtual void dump() = 0;
    BaseAST() {}
    virtual ~BaseAST() = default;
    // virtual void const_eval(BaseAST *&root) {
    //     throw std::logic_error("This function is not implemented");
    // }
    void const_eval(BaseAST *&root) {
        throw std::logic_error("This function is not implemented");
    }
};

struct DeclAST : public BaseAST {
public:
    // ConstDeclAST* const_decl;
    // VarDeclAST* var_decl;
    std::variant<ConstDeclAST*, VarDeclAST*> decl;
    DeclAST() {
        type = Type::DECL;
    }
    void const_eval(BaseAST *&root) ;
};

struct ExpAST : public BaseAST {
public:
    AddExpAST *add_exp;
    ExpAST() {
        type = Type::EXP;
    }
    // void eval();
    void const_eval(BaseAST *&root) {};
};

struct StmtAST : public BaseAST {
public:
    //std::variant<NullStmtAST*, ExpStmtAST*, AssignStmtAST*, BlockStmtAST*, IfStmtAST*, WhileStmtAST*, BreakStmtAST*, ContinueStmtAST*, ReturnStmtAST*> value;
    StmtAST() {
        type = Type::STMT;
    }
    void const_eval(BaseAST *&root) {};
};

struct CompUnitAST : public BaseAST {
public:
    std::vector<DeclAST*> decls;
    std::vector<FuncDefAST*> func_defs;
    std::vector<ExternalDefAST*> external_defs;
    CompUnitAST() {
        type = Type::COMPUNIT;
    }
    void const_eval(BaseAST *&root) ;
};

struct ExternalDefAST : public BaseAST {
public:
    std::string value = "#include ";
    ExternalDefAST(std::string header_file) {
        type = Type::EXTERNALDEF;
        value += header_file;
    }
    void const_eval(BaseAST *&root) {};
};

struct ConstExpAST : public BaseAST {
public:
    AddExpAST* add_exp;
    ConstExpAST() {
        type = Type::CONSTEXP;
    }
    void const_eval(BaseAST *&root) {};
};

struct ConstArrDefAST : public BaseAST {
public:
    std::string ident;
    std::vector<ExpAST*> dim;
    ConstArrDefAST() {
        type = Type::CONSTARRDEF;
    }
    void const_eval(BaseAST *&root) {};
};

struct ConstDeclAST : public BaseAST {
public:
    std::vector<ConstDefAST*> const_defs;
    ConstDeclAST() {
        type = Type::CONSTDECL;
    }
    void const_eval(BaseAST *&root) ;
};

struct ConstDefAST : public BaseAST {
public:
    std::string ident;
    // 数组维度，普通变量为空，数组变量为数组维度
    // 维度不一定是字面值常量，有可能是表达式
    // std::vector<ConstExpAST*> dim;
    std::vector<ExpAST*> dim;
    ConstInitValAST* const_init_val;
    ConstDefAST() {
        type = Type::CONSTDEF;
    }
    void const_eval(BaseAST *&root) {};
};

struct ConstDefListAST : public ConstDefAST {
public:
    std::vector<ConstDefAST*> const_defs;
    ConstDefListAST() {
        type = Type::CONSTDEFLIST;
    }
    void const_eval(BaseAST *&root) {};
};


struct ConstInitValAST : public BaseAST {
public:
    // std::variant<ConstExpAST*, ConstInitValListAST*> value;
    std::variant<ExpAST*, ConstInitValListAST*> value;
    ConstInitValAST() {
        type = Type::CONSTINITVAL;
    }
    void const_eval(BaseAST *&root) ;
};

struct ConstInitValListAST : public ConstInitValAST {
public:
    std::vector<ConstInitValAST*> const_init_vals;
    ConstInitValListAST() {
        type = Type::CONSTINITVALLIST;
    }
    void const_eval(BaseAST *&root) ;
};



struct ArrDefAST : public BaseAST {
public:
    std::string ident;
    std::vector<ExpAST*> dim;
    ArrDefAST() {
        type = Type::ARRDEF;
    }
    void const_eval(BaseAST *&root) {};
};

struct VarDeclAST : public BaseAST {
public:
    std::vector<VarDefAST*> var_defs;
    VarDeclAST() {
        type = Type::VARDECL;
    }
    void const_eval(BaseAST *&root) ;
};

struct VarDefAST : public BaseAST {
public:
    std::string ident;
    std::vector<ExpAST*> dim;
    InitValAST* init_val;
    VarDefAST() {
        type = Type::VARDEF;
    }
    void const_eval(BaseAST *&root) {};
};

struct VarDefListAST : public VarDefAST {
public:
    std::vector<VarDefAST*> var_defs;
    VarDefListAST() {
        type = Type::VARDEFLIST;
    }
    void const_eval(BaseAST *&root) {};
};

struct InitValAST : public BaseAST {
public:
    std::variant<ExpAST*, InitValListAST*> value;
    InitValAST() {
        type = Type::INITVAL;
    }
    void const_eval(BaseAST *&root) ;
};

struct InitValListAST : public InitValAST {
public:
    std::vector<InitValAST*> init_vals;
    InitValListAST() {
        type = Type::INITVALLIST;
    }
    void const_eval(BaseAST *&root) ;
};

struct FuncDefAST : public BaseAST {
public:
    bool return_type;
    std::string ident;
    std::vector<FuncFParamAST*> f_args;
    BlockAST* block;
    FuncDefAST() {
        type = Type::FUNCDEF;
    }
    void const_eval(BaseAST *&root) ;
};

struct FuncFParamAST : public BaseAST {
public:
    std::string ident;
    std::vector<ExpAST*> dim;
    FuncFParamAST() {
        type = Type::FUNCFPARAM;
    }
    void const_eval(BaseAST *&root) ;
};

struct FuncFParamsAST : public FuncFParamAST {
public:
    std::vector<FuncFParamAST*> f_args;
    FuncFParamsAST() {
        type = Type::FUNCFPARAMS;
    }
    void const_eval(BaseAST *&root) {};
};

struct BlockAST : public BaseAST {
public:
    // BlockGroupAST* block_group;
    std::vector<BlockItemAST*> block_items;
    BlockAST() {
        type = Type::BLOCK;
    }
    void const_eval(BaseAST *&root) ;
};

struct BlockGroupAST : public BaseAST {
public:
    std::vector<BlockItemAST*> block_items;
    BlockGroupAST() {
        type = Type::BLOCKGROUP;
    }
    void const_eval(BaseAST *&root) {};
};

struct BlockItemAST : public BaseAST {
public:
    std::variant<StmtAST*, DeclAST*> block_item;
    BlockItemAST() {
        type = Type::BLOCKITEM;
    }
    void const_eval(BaseAST *&root) ;
};

struct  LValAST : public BaseAST {
public:
    std::string ident;
    std::vector<ExpAST*> dim;
    LValAST() {
        type = Type::LVAL;
    }
    void const_eval(BaseAST *&root) {};
};



struct NullStmtAST : public StmtAST {
public:
    NullStmtAST() {
        type = Type::NULLSTMT;
    }
    void const_eval(BaseAST *&root) ;
};

struct AssignStmtAST : public StmtAST {
public:
    LValAST* lvalue;
    ExpAST* rvalue;
    AssignStmtAST() {
        type = Type::ASSIGNSTMT;
    }
    void const_eval(BaseAST *&root) ;
};

struct ExpStmtAST : public StmtAST {
public:
    ExpAST* exp;
    ExpStmtAST() {
        type = Type::EXPSTMT;
    }
    void const_eval(BaseAST *&root) ;
};

struct BlockStmtAST : public StmtAST {
public:
    // BlockAST* block;
    std::vector<BlockItemAST*> block_items;
    BlockStmtAST() {
        type = Type::BLOCKSTMT;
    }
    void const_eval(BaseAST *&root) ;
};

struct IfStmtAST : public StmtAST {
public:
    ExpAST* cond;
    StmtAST* then_stmt;
    StmtAST* else_stmt;
    IfStmtAST() {
        type = Type::IFSTMT;
    }
    void const_eval(BaseAST *&root) ;
};

struct WhileStmtAST : public StmtAST {
public:
    // CondAST* cond;
    ExpAST* cond;
    StmtAST* stmt;
    WhileStmtAST() {
        type = Type::WHILESTMT;
    }
    void const_eval(BaseAST *&root) ;
};

struct BreakStmtAST : public StmtAST {
public:
    BreakStmtAST() {
        type = Type::BREAKSTMT;
    }
    void const_eval(BaseAST *&root) ;
};

struct ContinueStmtAST : public StmtAST {
public:
    ContinueStmtAST() {
        type = Type::CONTINUESTMT;
    }void const_eval(BaseAST *&root) ;
};

struct ReturnStmtAST : public StmtAST {
public:
    ExpAST* exp;
    ReturnStmtAST() {
        type = Type::RETURNSTMT;
    }
    void const_eval(BaseAST *&root) ;
};

struct CondAST : public BaseAST {
public:
    LOrExpAST* l_or_exp;
    CondAST() {
        type = Type::COND;
    }
    void const_eval(BaseAST *&root) {};
};

struct PrimaryExpAST : public BaseAST {
public:
    std::variant<LValAST*, int, ExpAST*> value;
    PrimaryExpAST() {
        type = Type::PRIMARYEXP;
    }
    void const_eval(BaseAST *&root) {};
};

struct UnaryExpAST : public ExpAST {
public:
    std::string ident;
    std::string op;
    // std::variant<ExpAST*, UnaryExpAST*, FuncRParamsAST*> value;
    ExpAST* value;
    UnaryExpAST() {
        type = Type::UNARYEXP;
    }
    void const_eval(BaseAST *&root) ;
};

struct FuncCallAST : public ExpAST {
public:
    std::string ident;
    // FuncRParamsAST* r_params;
    std::vector<ExpAST*> r_args;
    FuncCallAST() {
        type = Type::FUNCCALL;
    }
    void const_eval(BaseAST *&root) ;
};

struct BinaryExpAST : public ExpAST {
public:
    std::string op;
    ExpAST* lhs;
    ExpAST* rhs;
    BinaryExpAST() {
        type = Type::BINARYEXP;
    }
    void const_eval(BaseAST *&root) ;
};

struct VarExpAST : public ExpAST {
public:
    std::string ident;
    std::vector<ExpAST*> dim;
    VarExpAST() {
        type = Type::VAREXP;
    }
    void const_eval(BaseAST *&root) ;
};

struct NumExpAST : public ExpAST {
public:
    int value;
    NumExpAST() {
        type = Type::PRIMARYEXP;
    }
    NumExpAST(int _value) : value(_value) {
        type = Type::PRIMARYEXP;
    }
    void const_eval(BaseAST *&root) ;
};

struct UnaryOpAST : public BaseAST {
public:
    std::string op;
    UnaryOpAST() {
        type = Type::UNARYOP;
    }
    void const_eval(BaseAST *&root) {};
};

struct FuncRParamsAST : public BaseAST {
public:
    std::string str = "";
    std::vector<ExpAST*> r_args;
    FuncRParamsAST() {
        type = Type::FUNCRPARAMS;
    }
    void const_eval(BaseAST *&root) {};
};

struct MulExpAST : public BaseAST {
public:
    UnaryExpAST* unary_exp;
    MulExpAST* mul_exp;
    std::string op;
    MulExpAST() {
        type = Type::MULEXP;
    }
    void const_eval(BaseAST *&root) {};
};

struct AddExpAST : public BaseAST {
public:
    MulExpAST* mul_exp;
    AddExpAST* add_exp;
    std::string op;
    AddExpAST() {
        type = Type::ADDEXP;
    }
    //int get_value();
    void const_eval(BaseAST *&root) {};
};

struct RelExpAST : public BaseAST {
public:
    AddExpAST* add_exp;
    RelExpAST* rel_exp;
    std::string rel_op;
    RelExpAST() {
        type = Type::RELEXP;
    }
    void const_eval(BaseAST *&root) {};
};

struct EqExpAST : public BaseAST {
public:
    RelExpAST* rel_exp;
    EqExpAST* eq_exp;
    std::string eq_op;
    EqExpAST() {
        type = Type::EQEXP;
    }
    void const_eval(BaseAST *&root) {};
};

struct LAndExpAST : public BaseAST {
public:
    EqExpAST* eq_exp;
    LAndExpAST* l_and_exp;
    LAndExpAST() {
        type = Type::LANDEXP;
    }
    void const_eval(BaseAST *&root) {};
};

struct LOrExpAST : public BaseAST {
public:
    LAndExpAST* l_and_exp;
    LOrExpAST* l_or_exp;
    LOrExpAST() {
        type = Type::LOREXP;
    }
    void const_eval(BaseAST *&root) {};
};

BaseAST* root;
void show();