#include <vector>
#include <string>
#include <cstdarg>
#include "AST.hpp"
#include "symbol_table.hpp"

// extern SymbolTable symbol_table;

class Assemble {
public:
    std::vector<std::string> code;

    void append(const char *format, ...);
    void print_info(FILE *file);
    void var_initialize(CompUnitAST* node);
} rodata, data, bss, text;

void Assemble::append(const char *format, ...) {
    va_list args;
    va_start(args, format);
    char buffer[1024];
    vsnprintf(buffer, 1024, format, args);
    code.push_back(buffer);
    va_end(args);
    code.push_back(buffer);
}

void Assemble::print_info(FILE *file) {
    for(auto &line : code) {
        fprintf(file, "%s", line.c_str());
    }
}

void assemble_init() {
    rodata.append(".section .rodata\n");
    data.append(".section .data\n");
    bss.append(".section .bss\n");
    text.append(".section .text\n");
}

void assemble_print(FILE *file) {
    rodata.print_info(file);
    data.print_info(file);
    bss.print_info(file);
    text.print_info(file);
}

// void Assemble::var_initialize(CompUnitAST* node) {
//     for (auto &decl : node->decls) {
//         if (decl->var_decl != nullptr && decl->const_decl == nullptr) {
//             for (auto &var_def : decl->var_decl->var_defs) {
//                 if(symbol_table.lookup(var_def->ident) != nullptr) {
//                     throw std::runtime_error("Variable " + var_def->ident + " already declared in this scope");
//                 }else {
//                     symbol_table.insert(var_def->ident, new Symbol(SymbolType::INTCONST, 0, 0));
//                     data.append("%s:\n", var_def->ident.c_str());
//                     data.append(".int 0\n");
//                 }
//             }
//         }else if (decl->const_decl != nullptr && decl->var_decl == nullptr) {
//             for (auto &const_def : decl->const_decl->const_defs) {
//                 if(symbol_table.lookup(const_def->ident) != nullptr) {
//                     throw std::runtime_error("Variable " + const_def->ident + " already declared in this scope");
//                 }else {
//                     symbol_table.insert(const_def->ident, new Symbol(SymbolType::CONST_INT, 0, const_def->value));
//                     rodata.append("%s:\n", const_def->ident.c_str());
//                     rodata.append(".int %d\n", const_def->value);
//                 }
//             }
//         }
//     }
// }