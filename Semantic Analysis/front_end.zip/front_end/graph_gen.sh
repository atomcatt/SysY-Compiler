dot -Tpng ./results/1/1-array.dot > ./results/1/1-array.png
echo "Generated ./results/1/1-array.png"
dot -Tpng ./results/2/2-comment.dot > ./results/2/2-comment.png
echo "Generated ./results/2/2-comment.png"
dot -Tpng ./results/3/3-globalvar.dot > ./results/3/3-globalvar.png
echo "Generated ./results/3/3-globalvar.png"
dot -Tpng ./results/4/4-exgcd.dot > ./results/4/4-exgcd.png
echo "Generated ./results/4/4-exgcd.png"
dot -Tpng ./results/5/5-kmp.dot > ./results/5/5-kmp.png
echo "Generated ./results/5/5-kmp.png"
dot -Tpng ./results/6/6-substr.dot > ./results/6/6-substr.png
echo "Generated ./results/6/6-substr.png"
dot -Tpng ./results/7/7-side_effect.dot > ./results/7/7-side_effect.png
echo "Generated ./results/7/7-side_effect.png"
dot -Tpng ./results/8/8-long_array.dot > ./results/8/8-long_array.png
echo "Generated ./results/8/8-long_array.png"
dot -Tpng ./results/9/9-many_params.dot > ./results/9/9-many_params.png
echo "Generated ./results/9/9-many_params.png"
dot -Tpng ./results/10/10-many_locals.dot > ./results/10/10-many_locals.png
echo "Generated ./results/10/10-many_locals.png"