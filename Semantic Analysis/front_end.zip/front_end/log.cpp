// Log.cpp
#include "log.hpp"

// Define the global log object
Log logger = Log("logfile.txt");

Log::Log(const std::string &filename) {
    logfile = std::make_unique<std::ofstream>(filename, std::ios::out | std::ios::app);
    if (!logfile->is_open()) {
        std::cerr << "Failed to open log file: " << filename << std::endl;
        throw std::runtime_error("Failed to open log file");
    }
}

Log::~Log() {
    if (logfile && logfile->is_open()) {
        logfile->close();
    }
}

std::ostream &Log::log(std::string_view module) {
    return log_(*logfile, module, false);
}

std::ostream &Log::err(std::string_view module) {
    return log_(*logfile, module, true);
}

std::ostream &Log::log_console(std::string_view module) {
    return log_(std::cout, module, false);
}

std::ostream &Log::err_console(std::string_view module) {
    return log_(std::cout, module, true);
}

std::ostream &Log::log_(std::ostream &out, std::string_view module, bool critical) {
    char leading = critical ? '!' : '+';
    out << "[" << leading << "] [" << std::setw(10) << std::left << module << std::right << "] ";
    return out;
}
